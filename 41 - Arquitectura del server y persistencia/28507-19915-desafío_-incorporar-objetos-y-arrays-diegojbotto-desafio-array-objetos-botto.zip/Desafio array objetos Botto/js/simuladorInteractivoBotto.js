

alert ("BIENVENIDO A CINE POP" + "\n" + "Para comprar entradas pulse en el boton OK");
//alert("Las peliculas disponibles son: " + "\n" + "1- Duro de matar" + "\n" + "2- Jurassic Park" + "\n" + "3- 101 Dalmatas" + "\n" + "4- Gladiador");

//Creacion de la clase cine, donde voy a guardar nombre y edad de los clientes
class Clientes {
    constructor (nombre, edad){
        this.nombre = nombre;
        this.edad = edad;
        this.esMayor = "";

    }
    mayorEdad() {

        if(this.edad >= 18) {

            this.esMayor=true;
        }else {
            this.esMayor=false;
        }

    }

}

//let opcion = prompt("Las peliculas disponibles son: " + "\n" + "1- Duro de matar" + "\n" + "2- Jurassic Park" + "\n" + "3- 101 Dalmatas" + "\n" + "4- Gladiador");
let pelicula = ""

    do {
        opcion = prompt("Las peliculas disponibles son: " + "\n" + "1- Duro de matar" + "\n" + "2- Jurassic Park" + "\n" + "3- 101 Dalmatas" + "\n" + "4- Buscando a Nemo");

        switch (opcion) {
            case "1":
                alert("HAS SELECCIONADO DURO DE MATAR");
                pelicula = "Duro de matar"
                break;
            case "2":
                alert("HAS SELECCIONADO JURASSIC PARK");
                pelicula = "Jurassic Park"
                break;
            case "3":
                alert("HAS SELECCIONADO 101 DALMATAS");
                pelicula = "101 Dalmatas"
                break
            case "4":
                alert("HAS SELECCIONADO BUSCANDO A NEMO");
                pelicula = "Buscando a Nemo"
                break;
            default:
                alert("NO HAS SELECCIONADO UNA OPCION CORRECTA!" + "\n" + "SELECCIONA DE 1 A 4");
                break;
            }

    } while (opcion != "1" && opcion != "2" && opcion != "3" && opcion != "4");


    let valorEntrada = 20;
    let cantidadEntradas = parseInt(prompt("Una entrada sale $" + valorEntrada + ", cuantas entradas quiere comprar?"));

     let array = [];

    for (let i=0; i < cantidadEntradas; i++){
        nombre = prompt ("Ingrese el nombre de la persona " + (i+1) +":")
        edad = prompt ("Ingrese la edad de la persona " + (i+1) +":")

        array [i] = new Clientes(nombre, edad)
        array [i].mayorEdad();

    }


    
        
        
        for (const clientes of array) {

            alert("PERSONA REGISTRADA: " + clientes.nombre + "EDAD: " + clientes.edad)
            
            

        }


    
    let sumas = sumaEntradas (cantidadEntradas);
    let monto = prompt("Con cuanto dinero va a pagar?");
    montoTotal (monto);

    do {
        opcion = prompt("Los Horarios disponibles son: " + "\n" + "1- 21:30" + "\n" + "2- 22:30" + "\n" + "3- 23:00" + "\n" + "4- 23:30");

        switch (opcion) {
            case "1":
                alert("HAS SELECCIONADO 21:30");
                alert("Gracias por tu compra!" + "\n" + "Su pelicula " + pelicula + " comenzara a las 21:30")
                break;
            case "2":
                alert("HAS SELECCIONADO 22:30");
                alert("Gracias por tu compra!" + "\n" + "Su pelicula " + pelicula + " comenzara a las 22:30")
                break;
            case "3":
                alert("HAS SELECCIONADO 23:00");
                alert("Gracias por tu compra!" + "\n" + "Su pelicula " + pelicula + " comenzara a las 23:00")
                break
            case "4":
                alert("HAS SELECCIONADO 23:30");
                alert("Gracias por tu compra!" + "\n" + "Su pelicula " + pelicula + " comenzara a las 23:00")
                break;
            default:
                alert("NO HAS SELECCIONADO UNA OPCION CORRECTA!" + "\n" + "SELECCIONA DE 1 A 4");
                break;
            }

           

    } while (opcion != "1" && opcion != "2" && opcion != "3" && opcion != "4");





function sumaEntradas(cantidad){

    let suma = (parseInt(valorEntrada) * parseInt(cantidad))
    alert("Total a pagar es: " + suma);
    return suma;
} 


function montoTotal (monto) {
     let sumaTotal = (parseInt(monto) - parseInt(sumas))
    alert("Su vuelto es: " + sumaTotal);
}

